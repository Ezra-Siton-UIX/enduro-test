{
	$seo_noframe: false,
	$seo_expander: true,
	$seo_hidden: false,
	title: 'hello world i am service2222222222',
	text: 'wow 22222222222222222222222222222222222222',
	seo: {
		title: 'hello world2',
		page_name: 'hello-world2',
		parent_page: 'שירותים',
		$seo_description_type: 'textarea',
		seo_description: '',
		seo_keywords: '',
		$open_graph_image_type: 'image',
		open_graph_image: 'https://cdn.meme.am/instances/500x/66927624.jpg',
		$title_en: 'wow i really like you',
		$parent_page_en: 'services'
	},
	$main_text_type: 'textarea',
	main_text: '<p>hello</p><p>world</p>',
	meta: {
		last_edited: 1511366754
	}
}
