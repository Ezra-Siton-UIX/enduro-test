{
	$seo_noframe: false,
	$seo_expander: true,
	$seo_hidden: false,

			title: 'hello world i am service',
			text: 'wow',

	seo: {
		title: 'hello world',
		page_name: 'hello-world',
		parent_page: 'שירותים',
		$seo_description_type: 'textarea',
		seo_description: '',
		seo_keywords: '',
		$open_graph_image_type: 'image',
		open_graph_image: 'https://cdn.meme.am/instances/500x/66927624.jpg',
		$title_en: 'wow i really like you'
	},

	$main_text_type: 'textarea',
	main_text: '<p>hello</p><p>world</p>',

}
