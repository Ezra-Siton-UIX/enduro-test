{
	greeting: 'you!',
	superlative: 'nice',
}
