{
	$seo_noframe: false,
	$seo_expander: true,
	$seo_hidden: false,
	seo: {
		title: 'אודות',
		$seo_description_type: 'textarea',
		seo_description: '',
		seo_keywords: '',
		$open_graph_image_type: 'image',
		open_graph_image: 'https://cdn.meme.am/instances/500x/66927624.jpg',
		$title_en: 'wow i really like you'
	},
	$greeting_noframe: false,
	$greeting_expander: true,
	greeting: 'אני מרגיש ממש מעולה תודה רבה',
	superlative: 'הכל טוב',
	meta: {
		last_edited: 1509222643
	},
	something: {
		something_else: ''
	},
	$greeting_en: 'howqwaed r you',
	$superlative_en: 'qwe'
}