{
	company_name: 'עזרא סיטון - מעצב',
	meta: {
		last_edited: 1509156279
	},
	direction: 'rtl',
	$direction_en: 'ltr',
	language: 'he',
	google_analytics: 'UA-107935375-1',
	$company_name_en: 'Company name',
	CSS: 'https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.31/css/uikit-rtl.min.css',
	$language_en: 'en',
	javascript: [
		{
			script: '33'
		},
		{
			script: '33'
		}
	],
	$CSS_en: 'https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.31/css/uikit.min.css',
	$google_analytics_en: 'UA-107935375-1'
}