{
	users: [
		{
			username: 'ezra',
			tags: [],
			salt: 'c6a1b490cab5806d95205ec51a68f8e0',
			hash: '63f309efed29f373a2a5ba3cc59dbc5a9fc7a91c6c4a97f509497bade9089102',
			user_created_timestamp: 1508975130350
		}
	]
}