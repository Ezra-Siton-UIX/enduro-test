{
	greeting: 'you! 2 2 3 2',
	superlative: 'nice',
	meta: {
		last_edited: 1508975482
	}
}